<?php

use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Cron Routes
|--------------------------------------------------------------------------
|
| Here is where you can register Cron routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "Cron" middleware group. Now create something great!
|
*/
